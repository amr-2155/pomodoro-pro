import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF6C63FF);
  static const primaryDark = Color(0xFF5A52D5);
  static const accent = Color(0xFFFF6584);
  static const success = Color(0xFF4CAF50);
  static const warning = Color(0xFFFF9800);
  static const error = Color(0xFFF44336);

  static const focusColor = Color(0xFF6C63FF);
  static const shortBreakColor = Color(0xFF4CAF50);
  static const longBreakColor = Color(0xFFFF9800);

  static const backgroundLight = Color(0xFFF5F5F8);
  static const backgroundDark = Color(0xFF1A1A2E);
  static const surfaceLight = Colors.white;
  static const surfaceDark = Color(0xFF16213E);
  static const textLight = Color(0xFF2D3436);
  static const textDark = Color(0xFFEAEAEA);

  static const projectColors = [
    Color(0xFF6C63FF),
    Color(0xFFFF6584),
    Color(0xFF4CAF50),
    Color(0xFFFF9800),
    Color(0xFF00BCD4),
    Color(0xFF9C27B0),
    Color(0xFFE91E63),
    Color(0xFF3F51B5),
    Color(0xFF009688),
    Color(0xFFFF5722),
  ];
}

class AppConstants {
  static const defaultFocusDuration = 25;
  static const defaultShortBreakDuration = 5;
  static const defaultLongBreakDuration = 15;
  static const maxSessionsBeforeLongBreak = 4;
  static const dailyGoalDefault = 8;

  static const projectIcons = [
    '🎯', '💻', '📚', '🎨', '🔬', '📝', '🎵', '🏋️',
    '🌟', '🔧', '📱', '🎮', '🧠', '💡', '🚀', '⭐',
    '🛠️', '📊', '🌍', '🎭',
  ];

  static const List<Map<String, String>> ambientSounds = [
    {'name': 'Rain', 'file': 'rain'},
    {'name': 'Forest', 'file': 'forest'},
    {'name': 'Ocean', 'file': 'ocean'},
    {'name': 'Fireplace', 'file': 'fireplace'},
    {'name': 'Cafe', 'file': 'cafe'},
    {'name': 'White Noise', 'file': 'white_noise'},
  ];
}

class AppTheme {
  static ThemeData lightTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorSchemeSeed: AppColors.primary,
      scaffoldBackgroundColor: AppColors.backgroundLight,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: AppColors.textLight,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: IconThemeData(color: AppColors.textLight),
      ),
      cardTheme: CardTheme(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }

  static ThemeData darkTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorSchemeSeed: AppColors.primary,
      scaffoldBackgroundColor: AppColors.backgroundDark,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: AppColors.textDark,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: IconThemeData(color: AppColors.textDark),
      ),
      cardTheme: CardTheme(
        elevation: 2,
        color: AppColors.surfaceDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: AppColors.surfaceDark,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}
