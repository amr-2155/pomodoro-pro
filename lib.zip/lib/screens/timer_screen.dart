import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/timer_service.dart';
import '../services/database_service.dart';
import '../models/session.dart';
import '../utils/constants.dart';
import '../widgets/timer_circle.dart';
import 'package:uuid/uuid.dart';

class TimerScreen extends StatefulWidget {
  const TimerScreen({super.key});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  String? _selectedProjectId;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() {
    final timerService = context.read<TimerService>();
    timerService.setFocusDuration(DatabaseService.focusDuration);
    timerService.setShortBreakDuration(DatabaseService.shortBreakDuration);
    timerService.setLongBreakDuration(DatabaseService.longBreakDuration);
    timerService.setAutoStartBreaks(DatabaseService.autoStartBreaks);
    timerService.setAutoStartPomodoros(DatabaseService.autoStartPomodoros);
  }

  Color _getModeColor(TimerMode mode) {
    switch (mode) {
      case TimerMode.focus:
        return AppColors.focusColor;
      case TimerMode.shortBreak:
        return AppColors.shortBreakColor;
      case TimerMode.longBreak:
        return AppColors.longBreakColor;
    }
  }

  void _showProjectPicker() {
    final projects = DatabaseService.getAllProjects();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Select Project',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              if (projects.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'No projects yet. Create one in the Projects tab.',
                    style: TextStyle(color: Colors.grey),
                  ),
                )
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: projects.length,
                    itemBuilder: (context, index) {
                      final project = projects[index];
                      final isSelected = _selectedProjectId == project.id;
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor:
                              Color(project.colorValue).withOpacity(0.15),
                          child: Text(project.icon,
                              style: const TextStyle(fontSize: 18)),
                        ),
                        title: Text(project.name),
                        trailing: isSelected
                            ? const Icon(Icons.check_circle,
                                color: AppColors.primary)
                            : null,
                        onTap: () {
                          setState(() => _selectedProjectId = project.id);
                          context.read<TimerService>().setProject(project.id);
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ),
              if (_selectedProjectId != null)
                TextButton(
                  onPressed: () {
                    setState(() => _selectedProjectId = null);
                    context.read<TimerService>().setProject(null);
                    Navigator.pop(context);
                  },
                  child: const Text('Clear Selection'),
                ),
            ],
          ),
        );
      },
    );
  }

  void _saveSession(bool completed) {
    if (_selectedProjectId == null) return;
    final timer = context.read<TimerService>();
    final session = Session(
      id: const Uuid().v4(),
      projectId: _selectedProjectId!,
      durationMinutes: timer.totalSeconds ~/ 60,
      completed: completed,
    );
    DatabaseService.addSession(session);
  }

  @override
  Widget build(BuildContext context) {
    final timer = context.watch<TimerService>();
    final color = _getModeColor(timer.mode);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          children: [
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: TimerMode.values.map((mode) {
                final isActive = timer.mode == mode;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: ChoiceChip(
                    label: Text(
                      mode == TimerMode.focus
                          ? 'Focus'
                          : mode == TimerMode.shortBreak
                              ? 'Short'
                              : 'Long',
                    ),
                    selected: isActive,
                    selectedColor: _getModeColor(mode),
                    labelStyle: TextStyle(
                      color: isActive ? Colors.white : Colors.grey,
                      fontWeight:
                          isActive ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (_) {
                      if (!timer.running) {
                        timer.setDuration(
                            mode,
                            mode == TimerMode.focus
                                ? DatabaseService.focusDuration
                                : mode == TimerMode.shortBreak
                                    ? DatabaseService.shortBreakDuration
                                    : DatabaseService.longBreakDuration);
                      }
                    },
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 40),
            TimerCircle(
              progress: timer.progress,
              time: timer.formattedTime,
              label: timer.modeLabel,
              color: color,
              isRunning: timer.running,
              onTap: () {
                if (timer.running) {
                  timer.pause();
                } else {
                  timer.start();
                }
              },
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildControlButton(
                  icon: Icons.refresh,
                  label: 'Reset',
                  onTap: timer.reset,
                  color: Colors.grey,
                ),
                const SizedBox(width: 24),
                _buildMainButton(timer, color),
                const SizedBox(width: 24),
                _buildControlButton(
                  icon: Icons.skip_next,
                  label: 'Skip',
                  onTap: timer.skip,
                  color: Colors.grey,
                ),
              ],
            ),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: _showProjectPicker,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: isDark ? AppColors.surfaceDark : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.folder_open,
                        color: _selectedProjectId != null
                            ? AppColors.primary
                            : Colors.grey),
                    const SizedBox(width: 8),
                    Text(
                      _selectedProjectId != null
                          ? DatabaseService.getProject(_selectedProjectId!)?.name ??
                              'Select Project'
                          : 'Select Project',
                      style: TextStyle(
                        color: _selectedProjectId != null
                            ? (isDark ? Colors.white : Colors.black87)
                            : Colors.grey,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(Icons.keyboard_arrow_down, color: Colors.grey),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.local_fire_department,
                    color: AppColors.warning, size: 20),
                const SizedBox(width: 4),
                Text(
                  '${timer.sessionCount} sessions today',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainButton(TimerService timer, Color color) {
    return GestureDetector(
      onTap: () {
        if (timer.running) {
          timer.pause();
        } else {
          timer.start();
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.4),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Icon(
          timer.running ? Icons.pause : Icons.play_arrow,
          color: Colors.white,
          size: 36,
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
  }) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.1),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 12, color: color)),
      ],
    );
  }
}
