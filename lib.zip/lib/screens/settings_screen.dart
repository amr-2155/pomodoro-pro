import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../utils/constants.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late int _focusDuration;
  late int _shortBreakDuration;
  late int _longBreakDuration;
  late bool _darkMode;
  late bool _autoStartBreaks;
  late bool _autoStartPomodoros;
  late bool _soundEnabled;
  late bool _vibrationEnabled;
  late int _dailyGoal;

  @override
  void initState() {
    super.initState();
    _focusDuration = DatabaseService.focusDuration;
    _shortBreakDuration = DatabaseService.shortBreakDuration;
    _longBreakDuration = DatabaseService.longBreakDuration;
    _darkMode = DatabaseService.darkMode;
    _autoStartBreaks = DatabaseService.autoStartBreaks;
    _autoStartPomodoros = DatabaseService.autoStartPomodoros;
    _soundEnabled = DatabaseService.soundEnabled;
    _vibrationEnabled = DatabaseService.vibrationEnabled;
    _dailyGoal = DatabaseService.dailyGoal;
  }

  void _saveSetting(String key, dynamic value) {
    DatabaseService.setSetting(key, value);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Settings',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 24),

            _buildSectionTitle('Timer'),
            _buildDurationTile(
              'Focus Duration',
              _focusDuration,
              (v) {
                setState(() => _focusDuration = v);
                _saveSetting('focusDuration', v);
              },
              min: 1,
              max: 90,
            ),
            _buildDurationTile(
              'Short Break',
              _shortBreakDuration,
              (v) {
                setState(() => _shortBreakDuration = v);
                _saveSetting('shortBreakDuration', v);
              },
              min: 1,
              max: 30,
            ),
            _buildDurationTile(
              'Long Break',
              _longBreakDuration,
              (v) {
                setState(() => _longBreakDuration = v);
                _saveSetting('longBreakDuration', v);
              },
              min: 1,
              max: 60,
            ),
            _buildSwitchTile(
              'Auto-start Breaks',
              'Automatically start break after a focus session',
              _autoStartBreaks,
              (v) {
                setState(() => _autoStartBreaks = v);
                _saveSetting('autoStartBreaks', v);
              },
            ),
            _buildSwitchTile(
              'Auto-start Focus',
              'Automatically start focus after a break',
              _autoStartPomodoros,
              (v) {
                setState(() => _autoStartPomodoros = v);
                _saveSetting('autoStartPomodoros', v);
              },
            ),

            const SizedBox(height: 16),
            _buildSectionTitle('Goals'),
            _buildDurationTile(
              'Daily Goal (hours)',
              _dailyGoal,
              (v) {
                setState(() => _dailyGoal = v);
                _saveSetting('dailyGoal', v);
              },
              min: 1,
              max: 16,
            ),

            const SizedBox(height: 16),
            _buildSectionTitle('Sound & Vibration'),
            _buildSwitchTile(
              'Sound Effects',
              'Play sound when session completes',
              _soundEnabled,
              (v) {
                setState(() => _soundEnabled = v);
                _saveSetting('soundEnabled', v);
              },
            ),
            _buildSwitchTile(
              'Vibration',
              'Vibrate when session completes',
              _vibrationEnabled,
              (v) {
                setState(() => _vibrationEnabled = v);
                _saveSetting('vibrationEnabled', v);
              },
            ),

            const SizedBox(height: 16),
            _buildSectionTitle('Appearance'),
            _buildSwitchTile(
              'Dark Mode',
              'Use dark theme',
              _darkMode,
              (v) {
                setState(() => _darkMode = v);
                _saveSetting('darkMode', v);
              },
            ),

            const SizedBox(height: 16),
            _buildSectionTitle('Data'),
            _buildActionTile(
              'Export Data',
              'Export your sessions as CSV',
              Icons.download,
              () => _exportData(),
            ),
            _buildActionTile(
              'Reset All Data',
              'Delete all sessions and projects',
              Icons.delete_forever,
              () => _confirmReset(),
              isDestructive: true,
            ),

            const SizedBox(height: 40),
            Center(
              child: Text(
                'Pomodoro App v1.0.0',
                style: TextStyle(color: Colors.grey[400], fontSize: 12),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
      ),
    );
  }

  Widget _buildDurationTile(
    String title,
    int value,
    ValueChanged<int> onChanged, {
    int min = 1,
    int max = 90,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.surfaceDark
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(title, style: const TextStyle(fontSize: 15)),
          ),
          IconButton(
            onPressed: value > min ? () => onChanged(value - 1) : null,
            icon: const Icon(Icons.remove_circle_outline),
            color: AppColors.primary,
          ),
          Text(
            '$value min',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          IconButton(
            onPressed: value < max ? () => onChanged(value + 1) : null,
            icon: const Icon(Icons.add_circle_outline),
            color: AppColors.primary,
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile(
    String title,
    String subtitle,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.surfaceDark
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: SwitchListTile(
        title: Text(title, style: const TextStyle(fontSize: 15)),
        subtitle: Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        value: value,
        onChanged: onChanged,
        activeColor: AppColors.primary,
        contentPadding: EdgeInsets.zero,
      ),
    );
  }

  Widget _buildActionTile(
    String title,
    String subtitle,
    IconData icon,
    VoidCallback onTap, {
    bool isDestructive = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.surfaceDark
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(icon,
                    color: isDestructive ? AppColors.error : AppColors.primary,
                    size: 22),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 15,
                          color: isDestructive ? AppColors.error : null,
                        ),
                      ),
                      Text(subtitle,
                          style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.grey),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _exportData() {
    final sessions = DatabaseService.getAllSessions();
    final csv = StringBuffer();
    csv.writeln('Date,Project,Duration (min),Completed');
    for (final s in sessions) {
      csv.writeln(
          '${s.date.toIso8601String()},${s.projectId},${s.durationMinutes},${s.completed}');
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Data exported! (Check documents folder)')),
    );
  }

  void _confirmReset() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset All Data'),
        content: const Text(
            'This will delete all your sessions and projects. This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              DatabaseService.getAllSessions().forEach(
                  (s) => DatabaseService.deleteSession(s.id));
              DatabaseService.getAllProjects().forEach(
                  (p) => DatabaseService.deleteProject(p.id));
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('All data has been reset')),
              );
            },
            child: const Text('Reset',
                style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
  }
}
