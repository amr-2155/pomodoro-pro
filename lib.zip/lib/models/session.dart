import 'package:hive/hive.dart';

part 'session.g.dart';

@HiveType(typeId: 1)
class Session extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String projectId;

  @HiveField(2)
  DateTime date;

  @HiveField(3)
  int durationMinutes;

  @HiveField(4)
  bool completed;

  @HiveField(5)
  String sessionType;

  @HiveField(6)
  int? rating;

  @HiveField(7)
  String? notes;

  Session({
    required this.id,
    required this.projectId,
    DateTime? date,
    required this.durationMinutes,
    this.completed = true,
    this.sessionType = 'focus',
    this.rating,
    this.notes,
  }) : date = date ?? DateTime.now();

  double get durationHours => durationMinutes / 60.0;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'projectId': projectId,
      'date': date.toIso8601String(),
      'durationMinutes': durationMinutes,
      'completed': completed,
      'sessionType': sessionType,
      'rating': rating,
      'notes': notes,
    };
  }

  factory Session.fromMap(Map<String, dynamic> map) {
    return Session(
      id: map['id'] ?? '',
      projectId: map['projectId'] ?? '',
      date: map['date'] != null ? DateTime.parse(map['date']) : DateTime.now(),
      durationMinutes: map['durationMinutes'] ?? 25,
      completed: map['completed'] ?? true,
      sessionType: map['sessionType'] ?? 'focus',
      rating: map['rating'],
      notes: map['notes'],
    );
  }
}
