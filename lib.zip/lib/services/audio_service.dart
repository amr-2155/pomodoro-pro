import 'package:audioplayers/audioplayers.dart';

class AudioService {
  static final AudioPlayer _player = AudioPlayer();
  static final AudioPlayer _ambientPlayer = AudioPlayer();

  static Future<void> playFinish() async {
    try {
      await _player.play(AssetSource('audio/finish.mp3'));
    } catch (e) {
      // Fallback: play a default system sound
    }
  }

  static Future<void> playClick() async {
    try {
      await _player.play(AssetSource('audio/click.mp3'));
    } catch (e) {
      // Silently fail
    }
  }

  static Future<void> playStart() async {
    try {
      await _player.play(AssetSource('audio/start.mp3'));
    } catch (e) {
      // Silently fail
    }
  }

  static Future<void> startAmbient(String sound) async {
    try {
      await _ambientPlayer.setReleaseMode(ReleaseMode.loop);
      await _ambientPlayer.play(AssetSource('audio/ambient/$sound.mp3'));
    } catch (e) {
      // Silently fail
    }
  }

  static Future<void> stopAmbient() async {
    try {
      await _ambientPlayer.stop();
    } catch (e) {
      // Silently fail
    }
  }

  static Future<void> setVolume(double volume) async {
    await _player.setVolume(volume);
  }

  static void dispose() {
    _player.dispose();
    _ambientPlayer.dispose();
  }
}
