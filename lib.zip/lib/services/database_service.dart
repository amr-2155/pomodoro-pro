import 'package:hive_flutter/hive_flutter.dart';
import '../models/project.dart';
import '../models/session.dart';

class DatabaseService {
  static const String _projectsBox = 'projects';
  static const String _sessionsBox = 'sessions';
  static const String _settingsBox = 'settings';

  static late Box<Project> _projects;
  static late Box<Session> _sessions;
  static late Box _settings;

  static Future<void> init() async {
    await Hive.initFlutter();

    Hive.registerAdapter(ProjectAdapter());
    Hive.registerAdapter(SessionAdapter());

    _projects = await Hive.openBox<Project>(_projectsBox);
    _sessions = await Hive.openBox<Session>(_sessionsBox);
    _settings = await Hive.openBox(_settingsBox);
  }

  // Projects
  static List<Project> getAllProjects() {
    return _projects.values.where((p) => !p.isArchived).toList();
  }

  static List<Project> getArchivedProjects() {
    return _projects.values.where((p) => p.isArchived).toList();
  }

  static Project? getProject(String id) {
    return _projects.get(id);
  }

  static Future<void> addProject(Project project) async {
    await _projects.put(project.id, project);
  }

  static Future<void> updateProject(Project project) async {
    await _projects.put(project.id, project);
  }

  static Future<void> deleteProject(String id) async {
    await _projects.delete(id);
  }

  static Future<void> archiveProject(String id) async {
    final project = _projects.get(id);
    if (project != null) {
      project.isArchived = true;
      await project.save();
    }
  }

  // Sessions
  static List<Session> getAllSessions() {
    return _sessions.values.toList();
  }

  static List<Session> getSessionsForProject(String projectId) {
    return _sessions.values
        .where((s) => s.projectId == projectId)
        .toList();
  }

  static List<Session> getSessionsForDate(DateTime date) {
    return _sessions.values.where((s) {
      return s.date.year == date.year &&
          s.date.month == date.month &&
          s.date.day == date.day;
    }).toList();
  }

  static List<Session> getSessionsForWeek() {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    return _sessions.values.where((s) {
      return s.date.isAfter(startOfWeek.subtract(const Duration(days: 1)));
    }).toList();
  }

  static List<Session> getSessionsForMonth() {
    final now = DateTime.now();
    return _sessions.values.where((s) {
      return s.date.year == now.year && s.date.month == now.month;
    }).toList();
  }

  static Future<void> addSession(Session session) async {
    await _sessions.put(session.id, session);

    final project = _projects.get(session.projectId);
    if (project != null && session.completed) {
      project.totalSessions++;
      project.totalMinutes += session.durationMinutes;
      await project.save();
    }
  }

  static Future<void> deleteSession(String id) async {
    final session = _sessions.get(id);
    if (session != null) {
      final project = _projects.get(session.projectId);
      if (project != null && session.completed) {
        project.totalSessions--;
        project.totalMinutes -= session.durationMinutes;
        await project.save();
      }
      await _sessions.delete(id);
    }
  }

  // Statistics
  static int getTodayMinutes() {
    final sessions = getSessionsForDate(DateTime.now());
    return sessions
        .where((s) => s.completed)
        .fold(0, (sum, s) => sum + s.durationMinutes);
  }

  static int getWeekMinutes() {
    final sessions = getSessionsForWeek();
    return sessions
        .where((s) => s.completed)
        .fold(0, (sum, s) => sum + s.durationMinutes);
  }

  static int getMonthMinutes() {
    final sessions = getSessionsForMonth();
    return sessions
        .where((s) => s.completed)
        .fold(0, (sum, s) => sum + s.durationMinutes);
  }

  static int getTodaySessions() {
    return getSessionsForDate(DateTime.now())
        .where((s) => s.completed)
        .length;
  }

  static int getWeekSessions() {
    return getSessionsForWeek()
        .where((s) => s.completed)
        .length;
  }

  static Map<String, int> getProjectMinutesThisWeek() {
    final sessions = getSessionsForWeek().where((s) => s.completed);
    final map = <String, int>{};
    for (final s in sessions) {
      map[s.projectId] = (map[s.projectId] ?? 0) + s.durationMinutes;
    }
    return map;
  }

  static List<double> getDailyMinutesThisWeek() {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final dailyMinutes = List<double>.filled(7, 0);

    for (int i = 0; i < 7; i++) {
      final day = startOfWeek.add(Duration(days: i));
      final daySessions = getSessionsForDate(day).where((s) => s.completed);
      dailyMinutes[i] =
          daySessions.fold(0, (sum, s) => sum + s.durationMinutes).toDouble();
    }
    return dailyMinutes;
  }

  static String? getBestProjectThisWeek() {
    final map = getProjectMinutesThisWeek();
    if (map.isEmpty) return null;
    final bestId = map.entries.reduce((a, b) => a.value > b.value ? a : b).key;
    return _projects.get(bestId)?.name;
  }

  static double getAverageSessionDuration() {
    final sessions = _sessions.values.where((s) => s.completed).toList();
    if (sessions.isEmpty) return 0;
    final total = sessions.fold(0, (sum, s) => sum + s.durationMinutes);
    return total / sessions.length;
  }

  // Settings
  static Future<void> setSetting(String key, dynamic value) async {
    await _settings.put(key, value);
  }

  static dynamic getSetting(String key, {dynamic defaultValue}) {
    return _settings.get(key, defaultValue: defaultValue);
  }

  static int get focusDuration => getSetting('focusDuration', defaultValue: 25);
  static int get shortBreakDuration =>
      getSetting('shortBreakDuration', defaultValue: 5);
  static int get longBreakDuration =>
      getSetting('longBreakDuration', defaultValue: 15);
  static bool get darkMode => getSetting('darkMode', defaultValue: false);
  static bool get autoStartBreaks =>
      getSetting('autoStartBreaks', defaultValue: true);
  static bool get autoStartPomodoros =>
      getSetting('autoStartPomodoros', defaultValue: false);
  static bool get soundEnabled =>
      getSetting('soundEnabled', defaultValue: true);
  static bool get vibrationEnabled =>
      getSetting('vibrationEnabled', defaultValue: true);
  static int get dailyGoal => getSetting('dailyGoal', defaultValue: 8);
}
