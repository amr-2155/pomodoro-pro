import 'dart:async';
import 'package:flutter/foundation.dart';
import 'audio_service.dart';
import 'notification_service.dart';

enum TimerMode { focus, shortBreak, longBreak }

class TimerService extends ChangeNotifier {
  Timer? _timer;
  int _seconds = 1500;
  int _totalSeconds = 1500;
  bool _running = false;
  TimerMode _mode = TimerMode.focus;
  int _sessionCount = 0;
  String? _currentProjectId;
  bool _autoStartBreaks = true;
  bool _autoStartPomodoros = false;

  int get seconds => _seconds;
  int get totalSeconds => _totalSeconds;
  bool get running => _running;
  TimerMode get mode => _mode;
  int get sessionCount => _sessionCount;
  String? get currentProjectId => _currentProjectId;
  bool get autoStartBreaks => _autoStartBreaks;
  bool get autoStartPomodoros => _autoStartPomodoros;

  double get progress =>
      _totalSeconds > 0 ? 1.0 - (_seconds / _totalSeconds) : 0.0;

  String get formattedTime {
    final mins = (_seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (_seconds % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  String get modeLabel {
    switch (_mode) {
      case TimerMode.focus:
        return 'Focus';
      case TimerMode.shortBreak:
        return 'Short Break';
      case TimerMode.longBreak:
        return 'Long Break';
    }
  }

  void setDuration(TimerMode mode, int minutes) {
    if (_running) return;
    _mode = mode;
    _seconds = minutes * 60;
    _totalSeconds = minutes * 60;
    notifyListeners();
  }

  void setProject(String? projectId) {
    _currentProjectId = projectId;
    notifyListeners();
  }

  void setAutoStartBreaks(bool value) {
    _autoStartBreaks = value;
    notifyListeners();
  }

  void setAutoStartPomodoros(bool value) {
    _autoStartPomodoros = value;
    notifyListeners();
  }

  void start() {
    if (_running) return;
    _running = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_seconds > 0) {
        _seconds--;
        notifyListeners();
      } else {
        _finish();
      }
    });
    notifyListeners();
  }

  void pause() {
    _timer?.cancel();
    _running = false;
    notifyListeners();
  }

  void reset() {
    _timer?.cancel();
    _running = false;
    _seconds = _totalSeconds;
    notifyListeners();
  }

  void skip() {
    _timer?.cancel();
    _running = false;
    _finish();
  }

  void _finish() {
    _timer?.cancel();
    _running = false;

    AudioService.playFinish();
    NotificationService.show(
      title: _mode == TimerMode.focus ? 'Focus Session Complete!' : 'Break Over!',
      body: _mode == TimerMode.focus
          ? 'Great work! Time for a break.'
          : 'Ready to focus again?',
    );

    if (_mode == TimerMode.focus) {
      _sessionCount++;
    }

    _switchMode();
    notifyListeners();
  }

  void _switchMode() {
    switch (_mode) {
      case TimerMode.focus:
        if (_sessionCount % 4 == 0) {
          _mode = TimerMode.longBreak;
          _seconds = 15 * 60;
          _totalSeconds = 15 * 60;
        } else {
          _mode = TimerMode.shortBreak;
          _seconds = 5 * 60;
          _totalSeconds = 5 * 60;
        }
        if (_autoStartBreaks) {
          Future.delayed(const Duration(seconds: 1), () => start());
        }
        break;
      case TimerMode.shortBreak:
      case TimerMode.longBreak:
        _mode = TimerMode.focus;
        _seconds = 25 * 60;
        _totalSeconds = 25 * 60;
        if (_autoStartPomodoros) {
          Future.delayed(const Duration(seconds: 1), () => start());
        }
        break;
    }
  }

  void setFocusDuration(int minutes) {
    if (!_running && _mode == TimerMode.focus) {
      _seconds = minutes * 60;
      _totalSeconds = minutes * 60;
      notifyListeners();
    }
  }

  void setShortBreakDuration(int minutes) {
    if (!_running && _mode == TimerMode.shortBreak) {
      _seconds = minutes * 60;
      _totalSeconds = minutes * 60;
      notifyListeners();
    }
  }

  void setLongBreakDuration(int minutes) {
    if (!_running && _mode == TimerMode.longBreak) {
      _seconds = minutes * 60;
      _totalSeconds = minutes * 60;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
