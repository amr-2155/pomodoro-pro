import 'package:flutter/material.dart';
import '../utils/constants.dart';

class SessionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final Color? color;
  final bool isPrimary;
  final bool isLarge;

  const SessionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
    this.color,
    this.isPrimary = false,
    this.isLarge = false,
  });

  @override
  Widget build(BuildContext context) {
    final buttonColor = color ?? AppColors.primary;

    if (isPrimary) {
      return SizedBox(
        width: isLarge ? double.infinity : null,
        height: isLarge ? 56 : null,
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(icon, size: isLarge ? 24 : 20),
          label: Text(
            label,
            style: TextStyle(
              fontSize: isLarge ? 18 : 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: buttonColor,
            foregroundColor: Colors.white,
            padding: EdgeInsets.symmetric(
              horizontal: isLarge ? 32 : 20,
              vertical: isLarge ? 16 : 12,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(isLarge ? 16 : 12),
            ),
            elevation: 4,
            shadowColor: buttonColor.withOpacity(0.4),
          ),
        ),
      );
    }

    return SizedBox(
      width: isLarge ? double.infinity : null,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: isLarge ? 24 : 20, color: buttonColor),
        label: Text(
          label,
          style: TextStyle(
            fontSize: isLarge ? 16 : 14,
            color: buttonColor,
            fontWeight: FontWeight.w600,
          ),
        ),
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.symmetric(
            horizontal: isLarge ? 24 : 16,
            vertical: isLarge ? 14 : 10,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(isLarge ? 16 : 12),
          ),
          side: BorderSide(color: buttonColor, width: 1.5),
        ),
      ),
    );
  }
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final Color? color;
  final double size;
  final String? tooltip;

  const RoundIconButton({
    super.key,
    required this.icon,
    required this.onPressed,
    this.color,
    this.size = 48,
    this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip ?? '',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(size / 2),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: (color ?? AppColors.primary).withOpacity(0.1),
            ),
            child: Icon(
              icon,
              color: color ?? AppColors.primary,
              size: size * 0.5,
            ),
          ),
        ),
      ),
    );
  }
}
